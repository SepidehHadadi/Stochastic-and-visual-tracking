clc
clear all
close all
X=[[1 1 0 0];[1 0 0 0];[ 0 0 1 1];[ 0 0 0 1 ]];
figure(3)
plot(X(1,:), X(3,:),'*r')
hold on
plot(X(2,:),X(4,:),'+g')
net = selforgmap([4 4]);
net = configure(net,X);
figure(1)
plotsompos(net)
net.trainParam.epochs = 1000;
net = train(net,X);
figure(2)
plotsompos(net)
% test after training
X1=[[0.0 0.0 0.0 0.9];[0.0 0.0 0.8 0.9];[0.7,0.0,0.0,0.0];[0.7 0.9 0.0 0.0]];
Y1=net(X1)
