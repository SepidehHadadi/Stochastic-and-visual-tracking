clc
clear all
close all
load('Data.mat')
load('test_data.mat')
X=[patient' control'];
figure(3)
for i=1:10
    plot(X(:,i), X(:,i+10),'*r')
    hold on
end
hold off
net = selforgmap([100 100]);
net = configure(net,X);
figure(1)
plotsompos(net)
net.trainParam.epochs = 100;
net = train(net,X);
figure(2)
plotsompos(net)
% test after training
X1=test_data';
%X1=[X(:,2) X(:,12) X(:,8)]
Y1=net(X1)