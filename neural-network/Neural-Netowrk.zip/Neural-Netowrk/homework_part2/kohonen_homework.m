
clear all
close all
clc


%% parameterization
% w=[0.2 0.6 0.5 0.9; 0.8 0.4 0.7 0.3];
w=rand([2,650]);
%x=[1 1 0 0; 0 0 0 1; 1 0 0 0; 0 0 1 1];
m=2;%number of clusters
alpha=0.6;
tmax=100;
n=4;%number of training vector
%% reading of data
delimiter='\t';
fid = fopen('patient.txt');
tline = fgets(fid);
i=0;
Label=[];
Data=[];
while ischar(tline) 
    splittedstring = strsplit(tline,delimiter);
    Data=[ Data ; splittedstring];
    i=i+1;
    tline = fgets(fid);
    Label=[Label 1];
end
fclose(fid);
fid = fopen('control.txt');
tline = fgets(fid);
i=0;
while ischar(tline) 
    splittedstring = strsplit(tline,delimiter);
    Data=[ Data ; splittedstring];
    i=i+1;
    tline = fgets(fid);
    Label=[Label 2];
end
fclose(fid);
n=size(Data,1);
x=Data;
%% training
for k=1:tmax
    for i=1:n
        x_pick=x(i,:);
        j = index_of_closest(x_pick, w);
        wc=w(j,:);
        wc = update_weights_h(wc, x_pick,alpha);
        w(j,:)=wc;
    end
    alpha=0.5*alpha;
end

%% test data
%input test vector
% v1=x(10,:);
% v2=x(5,:);
% v3=x(20,:);
% v4=x(15,:);
%[v1; v2; v3; v4]; %concatination of input vector
%verif =1;% this parameter can be set at "sepideh=1","solene=2","dummy=3"
verif =2;
load('test_Data.mat')
load('test_solene.mat')
if(verif == 1)
    v=test_sepideh;
else
    if(verif == 2)
       v=test_data;
    else
        v0= test_sepideh;
        v=v0;
        v(2,:)=v0(4,:);
        v(4,:)=v0(2,:);
    end
end
i=0;
mt=size(v,1);
class=ones(1,mt);
%% classification 
for i2=1:mt
   if(mag(v(i2,:)-w(1,:))>mag(v(i2,:)-w(2,:)))
     class(i2)=1;%class one
     class_label= 'control'
   else
       if(mag(v(i2,:)-w(1,:))<mag(v(i2,:)-w(2,:)))
       class(i2)=0;%class two
       class_label ='patient'
       else if(mag(v(i2,:)-w(1,:))<mag(v(i2,:)-w(2,:)))
               class(i2)=2;% border 
               class_label='non of control and patient'
           end
       end
   end
end
   

