function wn = update_weights_h(wo, x_pick,alpha)

wn=(1-alpha)*wo+alpha*x_pick;
